/**
 * Abstractions for members which can be targets of JUnit 4 rule annotations.
 */

package org.junit.jupiter.migrationsupport.rules.member;
