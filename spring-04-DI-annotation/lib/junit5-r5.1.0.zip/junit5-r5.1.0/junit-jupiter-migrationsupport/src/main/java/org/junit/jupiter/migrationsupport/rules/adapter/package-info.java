/**
 * Simple wrappers for JUnit 4 rules to overcome visibility limitations of the JUnit 4 implementations.
 */

package org.junit.jupiter.migrationsupport.rules.adapter;
