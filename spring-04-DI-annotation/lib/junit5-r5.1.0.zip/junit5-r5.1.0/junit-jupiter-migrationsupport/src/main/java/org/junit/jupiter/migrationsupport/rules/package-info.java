/**
 * Extensions which provide (limited) support for JUnit 4 rules within JUnit Jupiter.
 */

package org.junit.jupiter.migrationsupport.rules;
